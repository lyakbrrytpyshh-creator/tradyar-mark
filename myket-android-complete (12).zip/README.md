# 🎯 راهنمای کامل نصب درگاه مایکت (نهایی)

## 📦 محتویات پکیج

```
myket-android/
├── trad-yar-myket-fixed.html          # فایل HTML اصلی
├── build.gradle                       # Gradle پروژه
├── settings.gradle                    # تنظیمات Gradle
├── gradle.properties                  # تنظیمات Gradle
├── README.md                          # این فایل
└── app/
    ├── build.gradle                   # Gradle اپ + کلید عمومی مایکت
    ├── proguard-rules.pro             # ProGuard
    └── src/main/
        ├── AndroidManifest.xml        # Manifest با permission مایکت
        ├── assets/
        │   └── index.html             # فایل HTML برای WebView
        ├── java/app/tradyar/
        │   ├── MainActivity.java      # اکتیویتی با WebView
        │   ├── MyketBridge.java       # JavaScript Bridge مایکت
        │   └── CallbackManager.java   # مدیریت callback ها
        └── res/
            ├── layout/activity_main.xml
            ├── values/strings.xml
            ├── values/styles.xml
            └── xml/network_security_config.xml
```

## 🚀 مراحل نصب (طبق داکیومنت مایکت)

### مرحله ۱: دانلود و باز کردن پروژه

۱. فایل `myket-android-complete.zip` رو دانلود کن
۲. آن را extract کن
۳. اندروید استودیو رو باز کن
۴. **Open** رو بزن و پوشه `myket-android` رو انتخاب کن
۵. صبر کن تا Gradle Sync انجام بشه

### مرحله ۲: نصب SDK مایکت (طبق داکیومنت رسمی)

فایل `app/build.gradle` این تنظیمات رو داره (هست):

```gradle
android {
    defaultConfig {
        def marketApplicationId = "ir.mservices.market"
        def marketBindAddress = "ir.mservices.market.InAppBillingService.BIND"
        manifestPlaceholders = [
            marketApplicationId: "${marketApplicationId}",
            marketBindAddress  : "${marketBindAddress}",
            marketPermission   : "${marketApplicationId}.BILLING"
        ]
        buildConfigField "String", "IAB_PUBLIC_KEY", "\"YOUR_KEY\""
    }
}

dependencies {
    implementation 'com.github.myketstore:myket-billing-client:1.6'
}
```

فایل `build.gradle` (project level) این رو داره:

```gradle
allprojects {
    repositories {
        maven { url 'https://jitpack.io' }
    }
}
```

### مرحله ۳: Sync و Rebuild

طبق داکیومنت مایکت:
> "کتابخانه مایکت به ساختار کد شما اضافه شد. هم‌اکنون کافی است که پروژهٔ‌ خود را Sync و Rebuild کنید."

۱. در اندروید استودیو: **File → Sync Project with Gradle Files**
۲. صبر کن تا Gradle دانلود و sync بشه
۳. **Build → Rebuild Project**

### مرحله ۴: ثبت‌نام در پنل توسعه‌دهندگان مایکت

۱. برو به: https://developer.myket.ir
۲. حساب بساز
۳. **پکیج‌نام `app.tradyar` رو رزرو کن**
۴. **کلید عمومی (RSA PublicKey)** رو از پنل بگیر
۵. در فایل `app/build.gradle` و `MyketBridge.java` کلید خودت رو جایگزین کن

### مرحله ۵: تعریف محصولات در پنل مایکت

این SKU‌ها رو در پنل مایکت تعریف کن:

| SKU | توضیح | قیمت پیشنهادی |
|-----|--------|---------------|
| `tradyar_coins_p1` | ۵۰ سکه | ۳۹,۰۰۰ تومان |
| `tradyar_coins_p2` | ۱۲۰ سکه | ۷۹,۰۰۰ تومان |
| `tradyar_coins_p3` | ۳۰۰ سکه | ۱۷۹,۰۰۰ تومان |
| `tradyar_sub_sh1` | اشتراک نیم‌ساعته | ۹,۰۰۰ تومان |
| `tradyar_sub_sh2` | اشتراک ۱ ساعته | ۱۵,۰۰۰ تومان |
| `tradyar_sub_sh3` | اشتراک ۳ ساعته | ۳۵,۰۰۰ تومان |
| `tradyar_sub_sh4` | اشتراک ۶ ساعته | ۵۹,۰۰۰ تومان |
| `tradyar_sub_sh5` | اشتراک ۱۲ ساعته | ۹۹,۰۰۰ تومان |
| `tradyar_sub_s1` | اشتراک هفتگی | ۱۴۹,۰۰۰ تومان |
| `tradyar_sub_s2` | اشتراک ماهانه | ۲۴۹,۰۰۰ تومان |
| `tradyar_sub_s3` | اشتراک سه‌ماهه | ۵۴۹,۰۰۰ تومان |

### مرحله ۶: ساخت APK

۱. منوی **Build** → **Build Bundle(s) / APK(s)** → **Build APK(s)**
۲. صبر کن تا APK ساخته بشه
۳. APK رو پیدا کن (معمولاً در `app/build/outputs/apk/debug/app-debug.apk`)

### مرحله ۷: نصب APK روی گوشی

**روش ۱: با کابل USB**
- APK رو به گوشی منتقل کن
- روی APK کلیک کن و نصب کن

**روش ۲: با ADB**
```bash
adb install app/build/outputs/apk/debug/app-debug.apk
```

### مرحله ۸: نصب اپ مایکت (بسیار مهم!)

۱. برو به: https://myket.ir
۲. اپ مایکت رو دانلود و نصب کن

### مرحله ۹: تست درگاه مایکت

۱. ابتدا اپ مایکت رو باز کن (یک بار اجرا کن)
۲. برنامه ترید یار رو باز کن
۳. به صفحه «خرید توکن» برو
۴. روی «پرداخت با مایکت» کلیک کن
۵. ✅ **دیالوگ پرداخت مایکت باز میشه!**

## ⚠️ نکات خیلی مهم:

### ۱. حتما مایکت روی گوشی نصب باشه
بدون اپ مایکت، درگاه باز نمیشه.

### ۲. حتما برنامه از داخل مایکت باز بشه
اگه از دسکتاپ باز کنی، bridge کار نمی‌کنه. باید:
- مایکت رو باز کنی
- در مایکت، برنامه ترید یار رو جستجو کنی
- روی «باز کردن» کلیک کنی

### ۳. پکیج‌نیم باید یکسان باشه
`app.tradyar` در همه فایل‌ها و در پنل مایکت.

### ۴. کلید عمومی باید درست باشه
کلید رو از پنل توسعه‌دهندگان مایکت بگیر و در ۲ جا قرار بده:
- `app/build.gradle` (در `IAB_PUBLIC_KEY`)
- `MyketBridge.java` (در `BASE_64_PUBLIC_KEY`)

### ۵. SKU‌ها باید در پنل تعریف بشن
اگه SKU تعریف نشده باشه، خطا میده.

## 🔍 عیب‌یابی (Troubleshooting)

### مشکل: درگاه باز نمیشه

۱. در اندروید استودیو: **View → Tool Windows → Logcat**
۲. تگ `MyketBridge` رو فیلتر کن
۳. وقتی روی «پرداخت با مایکت» کلیک می‌کنی، این لاگ‌ها رو ببین:
   - `startSetup() called`
   - `Setup finished: Success`
   - `Setup successful. Querying inventory.`
   - `launchPurchaseFlow: ...`

اگه لاگ نبود یا خطا داد، این موارد رو بررسی کن:

| خطا | راه‌حل |
|------|--------|
| `IabHelper not setup` | مایکت نصب نیست |
| `Problem setting up in-app billing` | مایکت نصب نیست یا نسخه قدیمیه |
| `Error launching purchase flow` | SKU در پنل تعریف نشده |
| `Purchase not found in memory` | خطای داخلی - برنامه رو ریست کن |

### مشکل: سکه اضافه نمیشه

اگه پرداخت موفق بود ولی سکه اضافه نشد:

۱. در LogCat، تگ `MyketBridge` رو فیلتر کن
۲. دنبال `Consumption finished` بگرد
۳. اگه خطا داشت، لاگ رو بررسی کن

### مشکل: صفحه سفید

۱. فایل HTML رو در `app/src/main/assets/index.html` قرار بده
۲. مطمئن شو مسیر `file:///android_asset/index.html` درست هست

## 📞 پشتیبانی

اگه مشکلی داشتی:
- ایمیل پشتیبانی مایکت: developer@myket.ir
- [پایگاه دانش مایکت](https://knowledge.myket.ir)

## 🎉 موفق باشی!

اگه همه مراحل رو درست انجام بدی، درگاه پرداخت مایکت به‌صورت کامل کار می‌کنه!
