# ProGuard Rules - ترید یار با مایکت

# حفظ کلاس‌های مایکت
-keep class ir.mservices.** { *; }
-keep class com.myket.** { *; }
-dontwarn ir.mservices.**

# حفظ IabHelper و کلاس‌های پرداخت
-keep class **.IabHelper { *; }
-keep class **.IabResult { *; }
-keep class **.Inventory { *; }
-keep class **.Purchase { *; }
-keep class **.Security { *; }
-keep class **.SkuDetails { *; }

# حفظ JavaScript Bridge
-keepclassmembers class app.tradyar.MyketBridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keepclassmembers class app.tradyar.** {
    @android.webkit.JavascriptInterface <methods>;
}

# حفظ WebView
-keepclassmembers class * extends android.webkit.WebViewClient {
    public void *(android.webkit.WebView, java.lang.String, android.graphics.Bitmap);
    public boolean *(android.webkit.WebView, java.lang.String);
}
