package app.tradyar;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/**
 * ============================================================
 * MainActivity - اکتیویتی اصلی با WebView
 * ============================================================
 * این اکتیویتی:
 * ۱. WebView رو نمایش میده
 * ۲. JavaScript رو فعال می‌کنه
 * ۳. MyketBridge رو به JavaScript متصل می‌کنه
 * ۴. onActivityResult رو برای مایکت هندل می‌کنه
 * ۵. onDestroy رو برای پاکسازی مایکت صدا می‌زنه
 * ============================================================
 */

public class MainActivity extends Activity {
    private static final String TAG = "MainActivity";

    private WebView webView;
    private MyketBridge myketBridge;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // ساخت WebView
        webView = new WebView(this);
        setContentView(webView);

        // تنظیمات WebView
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        // فعال کردن debugging (در release غیرفعال کن)
        WebView.setWebContentsDebuggingEnabled(true);

        // WebViewClient
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                // لینک‌های مایکت رو باز کن
                if (url.startsWith("myket://") || url.startsWith("https://myket.ir") || url.startsWith("http://") || url.startsWith("https://")) {
                    view.loadUrl(url);
                    return true;
                }
                return false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                Log.d(TAG, "Page loaded: " + url);
            }
        });

        // WebChromeClient
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        request.grant(request.getResources());
                    }
                });
            }
        });

        // ============================================================
        // اضافه کردن MyketBridge به JavaScript
        // ============================================================
        // مهمترین بخش - bridge رو با نام "MyketBridge" در دسترس JavaScript قرار میده
        myketBridge = new MyketBridge(this, webView);
        webView.addJavascriptInterface(myketBridge, "MyketBridge");

        // بارگذاری فایل HTML از assets
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && webView.canGoBack()) {
            webView.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    /**
     * مدیریت onActivityResult برای مایکت
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // ارسال نتیجه به MyketBridge
        if (myketBridge != null) {
            myketBridge.handleActivityResult(requestCode, resultCode, data);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (myketBridge != null) {
            myketBridge.onDestroy();
        }
        if (webView != null) {
            webView.destroy();
        }
    }
}
