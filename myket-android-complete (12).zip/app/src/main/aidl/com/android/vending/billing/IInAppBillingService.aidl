/* ====================================================================
 * Copyright (c) 2012,2014 MYKET. All rights reserved.
 * Copyright (c) 2012 Google Inc.  All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ====================================================================
 */

package com.android.vending.billing;

import android.os.Bundle;

/**
 * InAppBillingService
 * Provides methods for in-app billing operations.
 */
interface IInAppBillingService {
    /**
     * Returns the API version supported by the in-app billing service.
     */
    int isBillingSupported(int apiVersion, String packageName, String type);

    /**
     * Returns a list of available packages for purchase.
     */
    Bundle getSkuDetails(int apiVersion, String packageName, String type, in Bundle skusBundle);

    /**
     * Returns a list of purchases made by the user.
     */
    Bundle getBuyIntent(int apiVersion, String packageName, String sku, String type, String developerPayload);

    /**
     * Returns a list of all purchases made by the user.
     */
    Bundle getPurchases(int apiVersion, String packageName, String type, String continuationToken);

    /**
     * Consumes a previously purchased item.
     */
    int consumePurchase(int apiVersion, String packageName, String purchaseToken);

    /**
     * Stub method for future use.
     */
    int stub(int apiVersion, String packageName, String type, String sku, String developerPayload, Bundle extra);
}
