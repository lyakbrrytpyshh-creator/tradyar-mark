# 🎯 راهنمای نهایی - پروژه مایکت طبق داکیومنت رسمی

عزیزم، این راهنما رو دقیقاً طبق داکیومنت رسمی مایکت ساختم. فقط باید این مراحل رو دنبال کنی.

## 📦 محتویات پکیج که بهت دادم:

```
myket-android/
├── trad-yar-myket-fixed.html          # فایل HTML اصلی
├── README.md
├── QUICK_START.md
├── SETUP_MYKET.md                     # این فایل
└── app/
    ├── build.gradle                   # با کلید عمومی + کتابخانه مایکت
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml        # با permission و queries
        ├── assets/index.html           # فایل HTML برای WebView
        ├── java/app/tradyar/
        │   ├── MainActivity.java
        │   ├── MyketBridge.java        # JavaScript Bridge
        │   └── CallbackManager.java
        └── res/
            ├── layout/activity_main.xml
            ├── values/{strings,styles}.xml
            └── xml/network_security_config.xml
```

## ⚠️ کارهایی که خودت باید انجام بدی:

طبق داکیومنت رسمی مایکت، باید **سه کار** انجام بدی:

### ۱. دانلود فایل‌های TrivialDrive از گیت‌هاب مایکت

طبق داکیومنت:
> "برنامه نمونه TrivialDrive را از اینجا دانلود کنید و یا در Github مشاهده نمایید"

۱. برو به: https://github.com/myketstore/MyketBillingSample
۲. پروژه رو دانلود کن (Download ZIP)
۳. استخراجش کن

### ۲. اضافه کردن فایل IInAppBillingService.aidl

طبق داکیومنت:
> "شما باید فایل IInAppBillingService.aidl را به پروژه اندروید خود اضافه کنید"

۱. در پروژه TrivialDrive که دانلود کردی، فایل زیر رو پیدا کن:
```
src/com/android/vending/billing/IInAppBillingService.aidl
```

۲. در پروژه خودت، این مسیر رو بساز:
```
app/src/main/aidl/com/android/vending/billing/
```

۳. فایل `IInAppBillingService.aidl` رو اونجا کپی کن.

۴. **Build → Rebuild Project** رو بزن. Gradle خودش فایل `IInAppBillingService.java` رو می‌سازه.

### ۳. اضافه کردن کلاس‌های کمکی

طبق داکیومنت:
> "کلاس‌های کمکی را از پوشه /util پروژه مثال TrivialDrive بردارید و به پروژه خود اضافه کنید"

۱. در پروژه TrivialDrive، به پوشه `src/util/` (یا مشابه) برو.

۲. این فایل‌های Java رو پیدا کن و کپی کن:
   - `IabHelper.java`
   - `IabResult.java`
   - `Inventory.java`
   - `Purchase.java`
   - `Security.java`
   - `SkuDetails.java`

۳. این فایل‌ها رو در پروژه خودت، در مسیر زیر قرار بده:
```
app/src/main/java/app/tradyar/utils/
```

۴. در ابتدای هر فایل، package رو تغییر بده:
```java
// از:
package com.example.android.trivialdrivesample.util;

// به:
package app.tradyar.utils;
```

۵. در فایل `MyketBridge.java`، import‌های زیر رو اضافه کن (اگه نبودن):
```java
import app.tradyar.utils.IabHelper;
import app.tradyar.utils.IabResult;
import app.tradyar.utils.Inventory;
import app.tradyar.utils.Purchase;
import app.tradyar.utils.IabAsyncInProgressException;
```

## ✅ کارهایی که من برات انجام دادم:

### ۱. پرمیشن مایکت در AndroidManifest.xml ✅
```xml
<uses-permission android:name="ir.mservices.market.BILLING" />
```

### ۲. تگ queries برای Android 11+ ✅
```xml
<queries>
    <package android:name="ir.mservices.market" />
    <intent>
        <action android:name="ir.mservices.market.InAppBillingService.BIND" />
        <data android:mimeType="*/*" />
    </intent>
</queries>
```

### ۳. کلید عمومی در build.gradle ✅
```gradle
buildConfigField "String", "IAB_PUBLIC_KEY", "\"MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC690jqkiBVMKuEhtalh6QrE5EjQmv5kwV1gHEy+zOtIxQUdtAp24uGcNLv5DCgQFAxs1FzSnzeBBSZldZc51SuwzSC3GfYH16B4AfRnWQhPTecKtH6q18taBUB8pgJRsoXmCbr8ZyDU7kHP51mXzTxQMSZ0plByDnw+MRvFrUjtwIDAQAB\""
```

### ۴. کلید عمومی در MyketBridge.java ✅
```java
private static final String BASE_64_PUBLIC_KEY = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC690jqkiBVMKuEhtalh6QrE5EjQmv5kwV1gHEy+zOtIxQUdtAp24uGcNLv5DCgQFAxs1FzSnzeBBSZldZc51SuwzSC3GfYH16B4AfRnWQhPTecKtH6q18taBUB8pgJRsoXmCbr8ZyDU7kHP51mXzTxQMSZ0plByDnw+MRvFrUjtwIDAQAB";
```

### ۵. کلید عمومی در index.html ✅
```javascript
const MYKET_PUBLIC_KEY='MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC690jqkiBVMKuEhtalh6QrE5EjQmv5kwV1gHEy+zOtIxQUdtAp24uGcNLv5DCgQFAxs1FzSnzeBBSZldZc51SuwzSC3GfYH16B4AfRnWQhPTecKtH6q18taBUB8pgJRsoXmCbr8ZyDU7kHP51mXzTxQMSZ0plByDnw+MRvFrUjtwIDAQAB';
```

### ۶. کتابخانه مایکت در build.gradle ✅
```gradle
implementation 'com.github.myketstore:myket-billing-client:1.6'
```

### ۷. کد Java برای IabHelper و startSetup ✅
در `MyketBridge.java` پیاده‌سازی شده.

### ۸. کد Java برای onDestroy ✅
در `MyketBridge.java` پیاده‌سازی شده:
```java
public void onDestroy() {
    if (mHelper != null) mHelper.disposeWhenFinished();
    mHelper = null;
}
```

## 🚀 مراحل نهایی:

### مرحله ۱: باز کردن پروژه
۱. اندروید استودیو رو باز کن
۲. **Open** → پوشه `myket-android` رو انتخاب کن
۳. صبر کن تا Gradle Sync بشه

### مرحله ۲: اضافه کردن فایل AIDL و کلاس‌های کمکی
طبق بخش "کارهایی که خودت باید انجام بدی" بالا.

### مرحله ۳: Build APK
۱. **Build → Build Bundle(s) / APK(s) → Build APK(s)**
۲. APK رو پیدا کن و نصب کن

### مرحله ۴: نصب اپ مایکت
از https://myket.ir اپ مایکت رو نصب کن.

### مرحله ۵: تست درگاه
۱. اپ مایکت رو باز کن
۲. از داخل مایکت، برنامه ترید یار رو باز کن
۳. روی «پرداخت با مایکت» کلیک کن
۴. ✅ **دیالوگ پرداخت مایکت باز میشه!**

## 🆘 عیب‌یابی:

اگه ارور داد:

| خطا | راه‌حل |
|------|--------|
| `Cannot resolve symbol IabHelper` | فایل‌های کلاس‌های کمکی رو کپی نکردی |
| `IInAppBillingService not found` | فایل AIDL رو در مسیر درست نذاشتی |
| `Permission denied` | پرمیشن مایکت در Manifest نیست |
| `Setup failed` | مایکت روی گوشی نصب نیست |

موفق باشی! 🎯
